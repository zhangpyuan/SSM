package com.sheefee.simple.sso.server.test;

public class MVCTest {

}
